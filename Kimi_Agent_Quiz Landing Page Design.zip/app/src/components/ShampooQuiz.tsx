import { useState } from "react"
import { cn } from "@/lib/utils"
import { Check, Leaf } from "lucide-react"

// Types
type HairType = "fine" | "medium" | "thick"
type HairTexture = "straight" | "wavy" | "curly" | "curly-coily" | "coily"
type HairConcern =
  | "damaged"
  | "thinning"
  | "volume"
  | "frizzy"
  | "dry"
  | "textured"
  | "oily"
  | "color-treated"

interface QuizState {
  currentStep: number
  hairType: HairType | null
  hairTexture: HairTexture | null
  hairConcern: HairConcern | null
}

interface ResultData {
  title: string
  line: string
  product: string
  description: string
  benefits: string[]
  url: string
}

// Result mapping based on hair concern (Question 3)
const resultMap: Record<HairConcern, ResultData> = {
  damaged: {
    title: "For Damaged Hair",
    line: "botanical repair",
    product: "Strengthening Shampoo",
    description:
      "Intensive repair for chemically or thermally damaged hair using plant-derived bond builders.",
    benefits: [
      "Repairs split ends and breakage",
      "Builds bonds within hair structure",
      "99% naturally derived ingredients",
    ],
    url: "https://www.aveda.com/hair-care/for-damaged-hair",
  },
  thinning: {
    title: "For Fine & Thinning Hair",
    line: "invati ultra advanced",
    product: "Exfoliating Shampoo",
    description:
      "Our most advanced formula for thinning hair, powered by Ayurvedic botanicals.",
    benefits: [
      "Reduces hair loss due to breakage",
      "Gently exfoliates scalp",
      "Thickens instantly from roots",
    ],
    url: "https://www.aveda.com/hair-care/invati-ultra-advanced-thinning-hair-solutions",
  },
  volume: {
    title: "For Hair Volume",
    line: "pure abundance",
    product: "Volumizing Shampoo",
    description:
      "Weightless volume for fine hair with plant-derived bulking agents.",
    benefits: [
      "Instantly builds volume",
      "Weightless conditioning",
      "Clay-based formula adds grip",
    ],
    url: "https://www.aveda.com/hair-care/pure-abundance-fine-hair",
  },
  frizzy: {
    title: "For Frizzy Hair",
    line: "smooth infusion",
    product: "Anti-Frizz Shampoo",
    description:
      "Eliminates frizz and protects against humidity with organic aloe and maize.",
    benefits: [
      "Reduces frizz by 50%",
      "Plant fiber technology smooths",
      "Protects against humidity",
    ],
    url: "https://www.aveda.com/hair-care/frizzy-hair",
  },
  dry: {
    title: "For Dry Hair",
    line: "nutriplenish",
    product: "Hydrating Shampoo",
    description:
      "Deep hydration with superfood complex of pomegranate and coconut oil.",
    benefits: [
      "72 hours of deep hydration",
      "Replenishes essential nutrients",
      "Lightweight or deep formula options",
    ],
    url: "https://www.aveda.com/hair-care/frizzy-hair",
  },
  textured: {
    title: "Coily, Curly & Wavy Hair",
    line: "be curly",
    product: "Enhancing Shampoo",
    description:
      "Defines and enhances natural curl pattern while combating frizz.",
    benefits: [
      "Enhances curl definition",
      "Reduces frizz by 57%",
      "Wheat protein and organic aloe blend",
    ],
    url: "https://www.aveda.com/textured-hair-products",
  },
  oily: {
    title: "Oily Hair & Scalp",
    line: "scalp solutions",
    product: "Balancing Shampoo",
    description:
      "Clarifies and balances sebum production with wintergreen-derived salicylic acid.",
    benefits: [
      "Deeply cleanses scalp buildup",
      "Balances oil production",
      "Extends time between washes",
    ],
    url: "https://www.aveda.com/products/scalp-solutions-dry-scalp-treatment",
  },
  "color-treated": {
    title: "Color Treated Hair",
    line: "color conserve",
    product: "Color Protection Shampoo",
    description:
      "Preserves color vibrancy and prevents fading with plant-derived antioxidants.",
    benefits: [
      "Extends color vibrancy",
      "Prevents water erosion of color",
      "Gentle, sulfate-free formula",
    ],
    url: "https://www.aveda.com/hair-care/color-care-treated-enrich",
  },
}

// Question data
const hairTypeOptions: { value: HairType; label: string; description: string; image: string }[] = [
  { value: "fine", label: "Fine", description: "I can barely feel the individual strand", image: "/images/type-fine.jpg" },
  { value: "medium", label: "Medium", description: "I can feel it slightly between my fingers", image: "/images/type-medium.jpg" },
  { value: "thick", label: "Thick", description: "I can feel it easily, it feels coarse", image: "/images/type-thick.jpg" },
]

const hairTextureOptions: { value: HairTexture; label: string; description: string; image: string }[] = [
  { value: "straight", label: "Straight", description: "No natural curl or wave pattern", image: "/images/texture-straight.jpg" },
  { value: "wavy", label: "Wavy", description: "Loose S-shaped waves", image: "/images/texture-wavy.jpg" },
  { value: "curly", label: "Curly", description: "Defined spiral or ringlet pattern", image: "/images/texture-curly.jpg" },
  { value: "curly-coily", label: "Curly-Coily", description: "Tight curls transitioning to coils", image: "/images/texture-curly-coily.jpg" },
  { value: "coily", label: "Coily", description: "Tight zig-zag or spring pattern", image: "/images/texture-coily.jpg" },
]

const hairConcernOptions: { value: HairConcern; label: string }[] = [
  { value: "damaged", label: "Damaged Hair" },
  { value: "thinning", label: "Fine & Thinning" },
  { value: "volume", label: "Lack of Volume" },
  { value: "frizzy", label: "Frizzy Hair" },
  { value: "dry", label: "Dry Hair" },
  { value: "textured", label: "Textured Hair Care" },
  { value: "oily", label: "Oily Hair & Scalp" },
  { value: "color-treated", label: "Color Treated" },
]

export function ShampooQuiz() {
  const [state, setState] = useState<QuizState>({
    currentStep: 0,
    hairType: null,
    hairTexture: null,
    hairConcern: null,
  })

  const totalSteps = 3
  const progressPercentage = state.currentStep === 0 ? 0 : (state.currentStep / totalSteps) * 100

  const goToStep = (step: number) => {
    setState((prev) => ({ ...prev, currentStep: step }))
  }

  const selectHairType = (value: HairType) => {
    setState((prev) => ({ ...prev, hairType: value }))
  }

  const selectHairTexture = (value: HairTexture) => {
    setState((prev) => ({ ...prev, hairTexture: value }))
  }

  const selectHairConcern = (value: HairConcern) => {
    setState((prev) => ({ ...prev, hairConcern: value }))
  }

  const restart = () => {
    setState({
      currentStep: 0,
      hairType: null,
      hairTexture: null,
      hairConcern: null,
    })
  }

  const result = state.hairConcern ? resultMap[state.hairConcern] : null

  return (
    <div className="min-h-screen bg-aveda-linen">
      <div className="mx-auto max-w-md min-h-screen bg-aveda-white flex flex-col">
        {/* Progress Bar - Hidden on start and results */}
        {state.currentStep > 0 && state.currentStep <= 3 && (
          <div className="sticky top-0 z-50 bg-aveda-white border-b border-aveda-linen-dark px-5 py-4">
            <div className="h-0.5 bg-aveda-linen-dark rounded-full overflow-hidden">
              <div
                className="h-full bg-aveda-green transition-all duration-400 ease-out"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
            <div className="flex justify-between mt-2">
              {["Hair Type", "Texture", "Concern"].map((label, index) => (
                <span
                  key={label}
                  className={cn(
                    "text-[11px] uppercase tracking-[0.1em]",
                    index + 1 <= state.currentStep
                      ? "text-aveda-green font-semibold"
                      : "text-aveda-gray"
                  )}
                >
                  {label}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Start Screen */}
        {state.currentStep === 0 && (
          <div className="flex-1 flex flex-col justify-center px-6 py-10 text-center animate-fadeIn">
            <div className="mb-6">
              <Leaf className="w-16 h-16 mx-auto text-aveda-green" strokeWidth={1} />
            </div>
            <p className="text-[11px] uppercase tracking-[0.2em] text-aveda-green font-semibold mb-3">
              Hair Care Finder
            </p>
            <h1 className="text-[32px] font-light leading-tight mb-4 text-aveda-black tracking-tight">
              Find Your Perfect Shampoo
            </h1>
            <p className="text-base text-aveda-gray leading-relaxed mb-8">
              Answer 3 simple questions about your hair to discover your personalized Aveda shampoo recommendation.
            </p>
            <button
              onClick={() => goToStep(1)}
              className="w-full py-4 bg-aveda-black text-aveda-white text-sm uppercase tracking-[0.1em] font-medium hover:bg-aveda-green-dark transition-colors"
            >
              Begin Consultation
            </button>
          </div>
        )}

        {/* Question 1: Hair Type */}
        {state.currentStep === 1 && (
          <div className="flex-1 flex flex-col animate-fadeIn">
            <div className="px-6 pt-8 pb-4 text-center">
              <p className="text-[11px] uppercase tracking-[0.2em] text-aveda-green font-semibold mb-2">
                Question 1 of 3
              </p>
              <h2 className="text-[28px] font-light leading-tight mb-2 text-aveda-black tracking-tight">
                What&apos;s your hair type?
              </h2>
              <p className="text-[15px] text-aveda-gray">
                Choose based on your individual strand thickness
              </p>
            </div>

            <div className="flex-1 px-6 pb-6">
              <div className="flex flex-col gap-3 mt-4">
                {hairTypeOptions.map((option) => (
                  <ImageAnswerCard
                    key={option.value}
                    label={option.label}
                    description={option.description}
                    image={option.image}
                    selected={state.hairType === option.value}
                    onClick={() => selectHairType(option.value)}
                  />
                ))}
              </div>

              <div className="flex gap-4 mt-auto pt-8">
                <button
                  disabled
                  className="flex-1 py-4 border border-aveda-black text-aveda-black text-sm uppercase tracking-[0.1em] font-medium opacity-30 cursor-not-allowed bg-transparent"
                >
                  Back
                </button>
                <button
                  onClick={() => goToStep(2)}
                  disabled={!state.hairType}
                  className={cn(
                    "flex-1 py-4 text-sm uppercase tracking-[0.1em] font-medium transition-colors",
                    state.hairType
                      ? "bg-aveda-black text-aveda-white hover:bg-aveda-green-dark"
                      : "bg-aveda-black text-aveda-white opacity-30 cursor-not-allowed"
                  )}
                >
                  Continue
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Question 2: Hair Texture */}
        {state.currentStep === 2 && (
          <div className="flex-1 flex flex-col animate-fadeIn">
            <div className="px-6 pt-8 pb-4 text-center">
              <p className="text-[11px] uppercase tracking-[0.2em] text-aveda-green font-semibold mb-2">
                Question 2 of 3
              </p>
              <h2 className="text-[28px] font-light leading-tight mb-2 text-aveda-black tracking-tight">
                What&apos;s your hair texture?
              </h2>
              <p className="text-[15px] text-aveda-gray">
                Select your natural hair pattern
              </p>
            </div>

            <div className="flex-1 px-6 pb-6">
              <div className="flex flex-col gap-3 mt-4">
                {hairTextureOptions.map((option) => (
                  <ImageAnswerCard
                    key={option.value}
                    label={option.label}
                    description={option.description}
                    image={option.image}
                    selected={state.hairTexture === option.value}
                    onClick={() => selectHairTexture(option.value)}
                  />
                ))}
              </div>

              <div className="flex gap-4 mt-auto pt-8">
                <button
                  onClick={() => goToStep(1)}
                  className="flex-1 py-4 border border-aveda-black text-aveda-black text-sm uppercase tracking-[0.1em] font-medium hover:bg-aveda-linen transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={() => goToStep(3)}
                  disabled={!state.hairTexture}
                  className={cn(
                    "flex-1 py-4 text-sm uppercase tracking-[0.1em] font-medium transition-colors",
                    state.hairTexture
                      ? "bg-aveda-black text-aveda-white hover:bg-aveda-green-dark"
                      : "bg-aveda-black text-aveda-white opacity-30 cursor-not-allowed"
                  )}
                >
                  Continue
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Question 3: Hair Concern */}
        {state.currentStep === 3 && (
          <div className="flex-1 flex flex-col animate-fadeIn">
            <div className="px-6 pt-8 pb-4 text-center">
              <p className="text-[11px] uppercase tracking-[0.2em] text-aveda-green font-semibold mb-2">
                Question 3 of 3
              </p>
              <h2 className="text-[28px] font-light leading-tight mb-2 text-aveda-black tracking-tight">
                What&apos;s your main hair concern?
              </h2>
              <p className="text-[15px] text-aveda-gray">
                Select the issue you&apos;d like to address most
              </p>
            </div>

            <div className="flex-1 px-6 pb-6 overflow-y-auto">
              <div className="grid grid-cols-2 gap-3 mt-4">
                {hairConcernOptions.map((option) => (
                  <ConcernCard
                    key={option.value}
                    label={option.label}
                    selected={state.hairConcern === option.value}
                    onClick={() => selectHairConcern(option.value)}
                  />
                ))}
              </div>

              <div className="flex gap-4 mt-auto pt-8">
                <button
                  onClick={() => goToStep(2)}
                  className="flex-1 py-4 border border-aveda-black text-aveda-black text-sm uppercase tracking-[0.1em] font-medium hover:bg-aveda-linen transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={() => goToStep(4)}
                  disabled={!state.hairConcern}
                  className={cn(
                    "flex-1 py-4 text-sm uppercase tracking-[0.1em] font-medium transition-colors",
                    state.hairConcern
                      ? "bg-aveda-black text-aveda-white hover:bg-aveda-green-dark"
                      : "bg-aveda-black text-aveda-white opacity-30 cursor-not-allowed"
                  )}
                >
                  See Results
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Results Screen */}
        {state.currentStep === 4 && result && (
          <div className="flex-1 flex flex-col px-6 py-10 animate-fadeIn">
            <div className="text-center">
              <div className="w-20 h-20 bg-aveda-green rounded-full flex items-center justify-center mx-auto mb-6">
                <Leaf className="w-10 h-10 text-aveda-white" strokeWidth={1.5} />
              </div>
              <p className="text-[11px] uppercase tracking-[0.2em] text-aveda-green font-semibold mb-2">
                Your Recommendation
              </p>
              <h2 className="text-2xl font-light leading-tight mb-4 text-aveda-black">
                {result.title}
              </h2>
              <p className="text-[15px] text-aveda-gray leading-relaxed mb-8">
                {result.description}
              </p>
            </div>

            <div className="bg-aveda-linen border border-aveda-linen-dark p-6 mb-6">
              <p className="text-xs uppercase tracking-[0.15em] text-aveda-green font-semibold mb-2">
                {result.line}
              </p>
              <h3 className="text-xl font-medium text-aveda-black mb-4">
                {result.product}
              </h3>
              <ul className="space-y-2">
                {result.benefits.map((benefit, index) => (
                  <li key={index} className="flex items-start gap-3 text-sm text-aveda-black/80">
                    <Check className="w-4 h-4 text-aveda-green flex-shrink-0 mt-0.5" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            <a
              href={result.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full py-4 bg-aveda-green text-aveda-white text-center text-sm uppercase tracking-[0.1em] font-medium hover:bg-aveda-green-dark transition-colors"
            >
              Shop Collection
            </a>
            <button
              onClick={restart}
              className="w-full py-4 mt-4 border border-aveda-black text-aveda-black text-sm uppercase tracking-[0.1em] font-medium hover:bg-aveda-black hover:text-aveda-white transition-colors"
            >
              Start Over
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

// Concern Card Component (for Hair Concern - 2 column grid)
function ConcernCard({
  label,
  selected,
  onClick,
}: {
  label: string
  selected: boolean
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full p-4 border text-center transition-all active:scale-[0.98]",
        selected
          ? "border-aveda-green bg-aveda-green/5"
          : "border-aveda-linen-dark bg-aveda-white hover:border-aveda-green/50"
      )}
    >
      <p className={cn(
        "text-sm font-medium",
        selected ? "text-aveda-green" : "text-aveda-black"
      )}>
        {label}
      </p>
    </button>
  )
}

// Image Answer Card Component (for Hair Texture)
function ImageAnswerCard({
  label,
  description,
  image,
  selected,
  onClick,
}: {
  label: string
  description: string
  image: string
  selected: boolean
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-4 p-3 border text-left transition-all active:scale-[0.98]",
        selected
          ? "border-aveda-green bg-aveda-green/5"
          : "border-aveda-linen-dark bg-aveda-white hover:border-aveda-green/50"
      )}
    >
      {/* Image on the left */}
      <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
        <img 
          src={image} 
          alt={`${label} hair texture`}
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* Text content on the right */}
      <div className="flex-1 min-w-0">
        <p className="text-base font-medium text-aveda-black">{label}</p>
        <p className="text-[13px] text-aveda-gray leading-snug">{description}</p>
      </div>
      
      {/* Checkmark when selected */}
      {selected && (
        <div className="w-5 h-5 bg-aveda-green rounded-full flex items-center justify-center flex-shrink-0">
          <Check className="w-3 h-3 text-aveda-white" strokeWidth={3} />
        </div>
      )}
    </button>
  )
}
