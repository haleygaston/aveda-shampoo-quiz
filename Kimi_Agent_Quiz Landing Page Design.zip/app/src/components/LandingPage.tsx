import { Leaf, Clock, Sparkles, ChevronRight } from "lucide-react"
import { useNavigate } from "react-router-dom"

export function LandingPage() {
  const navigate = useNavigate()

  const startQuiz = () => {
    navigate("/quiz")
  }

  return (
    <div className="min-h-screen bg-aveda-linen">
      <div className="mx-auto max-w-md min-h-screen bg-aveda-white flex flex-col">
        {/* Hero Section */}
        <div className="flex-1 flex flex-col">
          {/* Hero Image Area */}
          <div className="relative bg-gradient-to-b from-aveda-green/10 to-aveda-linen h-64 flex items-center justify-center">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-aveda-green/5 via-transparent to-transparent" />
            <div className="relative z-10 text-center">
              <div className="w-20 h-20 bg-aveda-green rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Leaf className="w-10 h-10 text-aveda-white" strokeWidth={1.5} />
              </div>
            </div>
          </div>

          {/* Content Area */}
          <div className="flex-1 px-6 py-8 flex flex-col">
            {/* Eyebrow */}
            <p className="text-[11px] uppercase tracking-[0.2em] text-aveda-green font-semibold mb-3 text-center">
              Hair Care Finder
            </p>

            {/* Headline */}
            <h1 className="text-[28px] font-light leading-tight mb-4 text-aveda-black tracking-tight text-center">
              Discover Your Perfect Hair Routine
            </h1>

            {/* Value Proposition */}
            <p className="text-base text-aveda-gray leading-relaxed mb-8 text-center">
              Answer a few quick questions and get personalized product recommendations tailored to your unique hair type and concerns.
            </p>

            {/* Benefits */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-aveda-linen p-4 text-center">
                <Clock className="w-5 h-5 text-aveda-green mx-auto mb-2" strokeWidth={1.5} />
                <p className="text-xs uppercase tracking-[0.1em] text-aveda-black font-medium mb-1">
                  Under 1 Minute
                </p>
                <p className="text-[13px] text-aveda-gray">
                  Quick & easy quiz
                </p>
              </div>
              <div className="bg-aveda-linen p-4 text-center">
                <Sparkles className="w-5 h-5 text-aveda-green mx-auto mb-2" strokeWidth={1.5} />
                <p className="text-xs uppercase tracking-[0.1em] text-aveda-black font-medium mb-1">
                  Personalized
                </p>
                <p className="text-[13px] text-aveda-gray">
                  Custom results
                </p>
              </div>
            </div>

            {/* What You'll Get */}
            <div className="mb-8">
              <p className="text-xs uppercase tracking-[0.15em] text-aveda-black font-medium mb-4">
                Your results include:
              </p>
              <ul className="space-y-3">
                {[
                  "Personalized shampoo recommendation",
                  "Tailored hair care routine",
                  "Product benefits & ingredients",
                  "Direct link to shop your match",
                ].map((item, index) => (
                  <li key={index} className="flex items-center gap-3 text-sm text-aveda-black/80">
                    <div className="w-1.5 h-1.5 bg-aveda-green rounded-full flex-shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* CTA Button */}
            <div className="mt-auto">
              <button
                onClick={startQuiz}
                className="w-full py-4 bg-aveda-black text-aveda-white text-sm uppercase tracking-[0.1em] font-medium hover:bg-aveda-green-dark transition-colors flex items-center justify-center gap-2 group"
              >
                Start Quiz
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
              <p className="text-[11px] text-aveda-gray text-center mt-4 leading-relaxed">
                By starting the quiz, you agree to our processing of your responses for personalized recommendations.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
