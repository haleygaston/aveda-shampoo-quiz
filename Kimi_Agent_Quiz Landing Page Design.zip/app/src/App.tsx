import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom"
import { LandingPage } from "./components/LandingPage"
import { ShampooQuiz } from "./components/ShampooQuiz"
import "./App.css"

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/quiz" element={<ShampooQuiz />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
